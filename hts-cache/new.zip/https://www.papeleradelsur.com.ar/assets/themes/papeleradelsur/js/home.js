/* CONTADOR */
var activar_contador = 0;
if (window.pageYOffset > section1.offsetTop) {
    if (activar_contador == 0) {
        activar_contador++;
        //console.log('Activar contador');
        let numero = document.querySelector('.counter');
        let cantidad = 0
        let cantidadZ = 0;
        let tiempo = setInterval(() => {
            cantidad += 500;
            cantidadZ = cantidad;
            nfObject = new Intl.NumberFormat('de-DE');
            output = nfObject.format(cantidadZ);
            numero.textContent = output
            if (cantidad === 59000) {
                clearInterval(tiempo)
            }
        }, 30);

        let numero2 = document.querySelector('.counter2');

        let cantidad2 = 0
        let tiempo2 = setInterval(() => {
            cantidad2 += 1
            numero2.textContent = cantidad2
            if (cantidad2 === 81) {
                clearInterval(tiempo2)
            }
        }, 30);
    }
}
window.addEventListener('scroll', () => {
    /********************************CONTADOR TRIGGER*****************************/
    if (window.pageYOffset > section1.offsetTop) {
        if (activar_contador == 0) {
            activar_contador++;
            //console.log('Activar contador');
            let numero = document.querySelector('.counter');
            let cantidad = 0
            let cantidadZ = 0;
            let tiempo = setInterval(() => {
                cantidad += 500;
                cantidadZ = cantidad;
                nfObject = new Intl.NumberFormat('de-DE');
                output = nfObject.format(cantidadZ);
                numero.textContent = output
                if (cantidad === 59000) {
                    clearInterval(tiempo)
                }
            }, 30);

            let numero2 = document.querySelector('.counter2');

            let cantidad2 = 0
            let tiempo2 = setInterval(() => {
                cantidad2 += 1
                numero2.textContent = cantidad2
                if (cantidad2 === 81) {
                    clearInterval(tiempo2)
                }
            }, 30);
        }
    }
})
/* /CONTADOR */

if (screen.width > 992) {
    var controller = new ScrollMagic.Controller();
    /* new ScrollMagic.Scene({
        triggerElement: "#leaf-s3-a",
        triggerHook: 0.9, // show, when scrolled 10% into view
        duration: "80%", // hide 10% before exiting view (80% + 10% from bottom)
        offset: 50 // move trigger to center of element
    })
        .setClassToggle("#leaf-s3-a", "slide-in-fwd-center") // add class to reveal
        .addTo(controller); */

    new ScrollMagic.Scene({
        triggerElement: ".section-2",
        triggerHook: 0.9, // show, when scrolled 10% into view
        duration: "90%", // hide 10% before exiting view (80% + 10% from bottom)
        offset: 50 // move trigger to center of element
    })
        .setClassToggle(".leaf-s2-a", "left-0")
        .addTo(controller);

    /* new ScrollMagic.Scene({
        triggerElement: "#leaf-s2-b",
        triggerHook: 0.9, // show, when scrolled 10% into view
        duration: "80%", // hide 10% before exiting view (80% + 10% from bottom)
        offset: 50 // move trigger to center of element
    })
        .setClassToggle("#leaf-s2-b", "slide-in-fwd-center") // add class to reveal
        .addTo(controller); */

    /* 
                    new ScrollMagic.Scene({
                        triggerElement: ".mask-s3",
                        triggerHook: 0.9, // show, when scrolled 10% into view
                        duration: "80%", // hide 10% before exiting view (80% + 10% from bottom)
                        offset: 50 // move trigger to center of element
                    })
                        .setClassToggle(".mask-s3", "rotate0") // add class to reveal
                        .addTo(controller);
    
    
                    new ScrollMagic.Scene({
                        triggerElement: ".mask-s4",
                        triggerHook: 0.9, // show, when scrolled 10% into view
                        duration: "80%", // hide 10% before exiting view (80% + 10% from bottom)
                        offset: 50 // move trigger to center of element
                    })
                        .setClassToggle(".mask-s4", "rotate0") // add class to reveal
                        .addTo(controller);
                    new ScrollMagic.Scene({
                        triggerElement: ".mask-s5",
                        triggerHook: 0.9, // show, when scrolled 10% into view
                        duration: "80%", // hide 10% before exiting view (80% + 10% from bottom)
                        offset: 50 // move trigger to center of element
                    })
                        .setClassToggle(".mask-s5", "rotate0") // add class to reveal
                        .addTo(controller);
    
                    new ScrollMagic.Scene({
                        triggerElement: ".mask-s6",
                        triggerHook: 0.9, // show, when scrolled 10% into view
                        duration: "80%", // hide 10% before exiting view (80% + 10% from bottom)
                        offset: 50 // move trigger to center of element
                    })
                        .setClassToggle(".mask-s6", "rotate0") // add class to reveal
                        .addTo(controller);
     */

    new ScrollMagic.Scene({
        triggerElement: ".img-s8",
        triggerHook: 0.5, // show, when scrolled 10% into view
        duration: "80%", // hide 10% before exiting view (80% + 10% from bottom)
        offset: 50 // move trigger to center of element
    })
        .setClassToggle(".img-s8", "transform-1-3") // add class to reveal
        .addTo(controller);
}