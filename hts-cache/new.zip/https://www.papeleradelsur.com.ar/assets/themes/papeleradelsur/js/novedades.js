// function activeFilter(clase){
//     let item_filter = document.querySelectorAll('.item-filter');
//     for(let i = 0; i < item_filter.length; i++){
//         item_filter[i].classList.remove('filter-active');
//     }
    
//     document.querySelector(clase).classList.add('filter-active');
// }
// activeFilter('.filter-1');

// FILTERS

const filters = document.querySelectorAll('.filter')
const filtersMob = document.querySelectorAll('.options-opt')
const contents = document.querySelectorAll('.contents');
// DESKTOP
filters.forEach((btn) => {
  btn.addEventListener('click', function(e) {
    filters.forEach((btn) => {
      btn.classList.remove('filter-active');
    });
    e.currentTarget.classList.add('filter-active');
    contents.forEach((content) => {
      content.classList.remove('show');
    });
    dataset = document.getElementById(e.currentTarget.dataset.content);
    dataset.classList.add('show');
  });
});

// MOBILE
filtersMob.forEach((btn) => {
    btn.addEventListener('click', function(e) {
      contents.forEach((content) => {
        content.classList.remove('show');
      });
      dataset = document.getElementById(e.currentTarget.dataset.option);
      dataset.classList.add('show');
    });
  });
console.log('novedades')