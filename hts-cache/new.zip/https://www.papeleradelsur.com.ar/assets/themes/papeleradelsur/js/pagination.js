


var SlickPagination = function(options) {
	var self = this;
	this.perPage = 9;
	this.visiblePages = 4;
    
	if (!options.itemsContainer || !options.paginationContainer) {
		console.warn('ERROR SETTINGS');
	}
	for (var key in options) {
		this[key] = options[key];
	}
    const next = `<img data-page='next' src='${this.domain}/icon/next-prev.svg' alt=''>`
    const prev = `<img data-page='prev' src='${this.domain}/icon/next-prev.svg' alt=''>`
	this.items = this.itemsContainer.children;
	this.numberOfItems = this.items.length;
	this.totalPages = parseInt(Math.ceil(this.numberOfItems / this.perPage));
	this.visibilePages = (this.totalPages < this.visiblePages) ? this.totalPages : this.visiblePages;
	for (var i = 0; i < this.items.length; i++) {
		if (i < this.perPage) {
			this.items[i].style.display = 'block';
		}
	}
	this.attachClickEvents = function() {
		var pageLinks = this.paginationContainer.querySelectorAll('p');
		for (var i = 0; i < pageLinks.length; i++) {
			var pageLink = pageLinks[i];
			pageLink.onclick = function(e) {
				e.preventDefault();
				var page = e.target.dataset.page;
				var currentPage = parseInt(self.paginationContainer.querySelector('.page-active').innerText);
				var newPage = 
					(page == 'prev') ? currentPage - 1
					: (page == 'next') ? currentPage + 1
					: parseInt(page);

				if (newPage > 0 && newPage <= self.totalPages) {
					var	startItem = parseInt(newPage * self.perPage) - self.perPage;
					var endItem = parseInt(startItem + self.perPage) - 1;
					var startPage = newPage - Math.floor(self.visibilePages / 2);
					var endPage = newPage + Math.floor(self.visibilePages / 2);

					for (var j = 0; j < self.items.length; j++) {
						self.items[j].style.display = (j >= startItem && j <= endItem) ? 'block' : 'none';
					}

					if (newPage < (self.visibilePages - Math.ceil(self.visibilePages / 2)) + 1) {
						startPage = 1;
						endPage = self.visibilePages;
					} else if (newPage > self.totalPages - Math.ceil(self.visibilePages / 2)) {
						startPage = self.totalPages - (self.visibilePages - 1);
						endPage = self.totalPages;
					}

					self.buildPagination(startPage, endPage, newPage);
				}
				
				// window.scrollTo(0, self.itemsContainer.getBoundingClientRect().top + window.scrollY - 200);
			};
		}
	};


	this.buildPagination = function(startPage, endPage, currentPage) {
		var pageLinks = '';
		var backDisabled = (currentPage === 1) ? 'disabled' : '';
		var nextDisabled = (currentPage === this.totalPages) ? 'disabled' : '';

        var backLinks = (this.totalPages > this.visiblePages) ? `<p data-page='prev' style='cursor: pointer;' class='prev page-p d-flex justify-content-center align-items-center ${backDisabled}'>${prev}</p>` : '';
        var nextLinks = (this.totalPages > this.visiblePages) ? `<p  data-page='next' style='cursor: pointer;' class='next page-p d-flex justify-content-center align-items-center ${nextDisabled}'>${next}</p>` : '';
		for (var i = startPage; i <= endPage; i++) {
			var active = (i === currentPage) ? ' page-active' : '';
            pageLinks += `<p class="page-p text-center text-green-primary text-bold d-flex justify-content-center align-items-center ${active}"  data-page=${i} >${i}</p>`;
		}
		this.paginationContainer.innerHTML = backLinks + pageLinks + nextLinks;

		this.attachClickEvents();
	};

	this.buildPagination(1, this.visibilePages, 1);
};



