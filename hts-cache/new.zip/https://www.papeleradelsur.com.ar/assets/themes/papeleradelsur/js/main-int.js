function myFunction(x) {
    x.classList.toggle("change");
}
let links = document.querySelectorAll('.header-link');
let divlan = document.querySelector('.div-lan');

document.querySelector('header').setAttribute("style", "box-shadow: 2px 1px 2px 1px rgba(0, 0, 0, 0.1);");
document.querySelector('#logo-white').setAttribute("style", "display : none");
document.querySelector('#logo-color').setAttribute("style", "display : block");
document.querySelector('.header-desk').setAttribute("style", "background-color : rgba(255,255,255,1) !important");
for (var i = 0; i < links.length; i++) {
    links[i].setAttribute("style", "color : #000");
}
// divlan.setAttribute("style", "background-color : #000");
