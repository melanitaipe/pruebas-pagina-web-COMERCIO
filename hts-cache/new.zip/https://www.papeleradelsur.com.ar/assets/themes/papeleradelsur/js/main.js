function myFunction(x) {
    x.classList.toggle("change");
}
let section1 = document.querySelector('.section-1');
var fx_nav = 0; // Para el Transparent del Nav
let links = document.querySelectorAll('.header-link');
let divlan = document.querySelector('.div-lan');

if (window.pageYOffset > section1.offsetTop) {
    fx_nav = window.pageYOffset / 200;
    document.querySelector('header').setAttribute("style", "box-shadow: 2px 1px 2px 1px rgba(0, 0, 0, 0.1);");
    document.querySelector('#logo-white').setAttribute("style", "display : none");
    document.querySelector('#logo-color').setAttribute("style", "display : block");
    document.querySelector('.header-desk').setAttribute("style", "background-color : rgba(255,255,255," + fx_nav + ") !important");
    for (var i = 0; i < links.length; i++) {
        links[i].setAttribute("style", "color : #000");
    }
    // divlan.setAttribute("style", "background-color : #000");
} else {
    document.querySelector('header').setAttribute("style", "");
    document.querySelector('.header-desk').setAttribute("style", "");
    for (var i = 0; i < links.length; i++) {
        links[i].setAttribute("style", "");
    }
    divlan.setAttribute("style", "");
    document.querySelector('#logo-white').setAttribute("style", "");
    document.querySelector('#logo-color').setAttribute("style", "display : none");
}

window.addEventListener('scroll', () => {
    /********************************NAV COLOR*****************************/
    if (window.pageYOffset > section1.offsetTop) {
        fx_nav = window.pageYOffset / 200;
        document.querySelector('header').setAttribute("style", "box-shadow: 2px 1px 2px 1px rgba(0, 0, 0, 0.1);");
        document.querySelector('#logo-white').setAttribute("style", "display : none");
        document.querySelector('#logo-color').setAttribute("style", "display : block");
        document.querySelector('.header-desk').setAttribute("style", "background-color : rgba(255,255,255," + fx_nav + ") !important");
        for (var i = 0; i < links.length; i++) {
            links[i].setAttribute("style", "color : #000");
        }
        // divlan.setAttribute("style", "background-color : #000");
    } else {
        document.querySelector('header').setAttribute("style", "");
        document.querySelector('.header-desk').setAttribute("style", "");
        for (var i = 0; i < links.length; i++) {
            links[i].setAttribute("style", "");
        }
        divlan.setAttribute("style", "");
        document.querySelector('#logo-white').setAttribute("style", "");
        document.querySelector('#logo-color').setAttribute("style", "display : none");
    }
    //console.log(window.fx_nav);
})