if (screen.width > 992) {
    if (document.querySelectorAll(".tile")) {
        let elementsArray = document.querySelectorAll(".tile");
        console.log(elementsArray);
        window.addEventListener('scroll', fadeIn);
        function fadeIn() {
            for (var i = 0; i < elementsArray.length; i++) {
                var elem = elementsArray[i]
                var distInView = elem.getBoundingClientRect().top - window.innerHeight + 20;
                if (distInView < 0) {
                    elem.classList.add("inView");
                } else {
                    elem.classList.remove("inView");
                }
            }
        }
        fadeIn();
    }
    if (document.querySelectorAll(".tile-2")) {
        let elementsArray = document.querySelectorAll(".tile-2");
        console.log(elementsArray);
        window.addEventListener('scroll', fadeIn);
        function fadeIn() {
            for (var i = 0; i < elementsArray.length; i++) {
                var elem = elementsArray[i]
                var distInView = elem.getBoundingClientRect().top - window.innerHeight + 20;
                if (distInView < 0) {
                    elem.classList.add("inView");
                } else {
                    elem.classList.remove("inView");
                }
            }
        }
        fadeIn();
    }
    if (document.querySelectorAll(".tile-3")) {
        let elementsArray = document.querySelectorAll(".tile-3");
        console.log(elementsArray);
        window.addEventListener('scroll', fadeIn);
        function fadeIn() {
            for (var i = 0; i < elementsArray.length; i++) {
                var elem = elementsArray[i]
                var distInView = elem.getBoundingClientRect().top - window.innerHeight + 20;
                if (distInView < 0) {
                    elem.classList.add("inView");
                } else {
                    elem.classList.remove("inView");
                }
            }
        }
        fadeIn();
    }
    if (document.querySelectorAll(".tile-4")) {
        let elementsArray = document.querySelectorAll(".tile-4");
        console.log(elementsArray);
        window.addEventListener('scroll', fadeIn);
        function fadeIn() {
            for (var i = 0; i < elementsArray.length; i++) {
                var elem = elementsArray[i]
                var distInView = elem.getBoundingClientRect().top - window.innerHeight + 20;
                if (distInView < 0) {
                    elem.classList.add("inView");
                } else {
                    elem.classList.remove("inView");
                }
            }
        }
        fadeIn();
    }


    if (document.querySelectorAll(".tile-l")) {
        let elementsArrayL = document.querySelectorAll(".tile-l");
        console.log(elementsArrayL);
        window.addEventListener('scroll', fadeInL);
        function fadeInL() {
            for (var i = 0; i < elementsArrayL.length; i++) {
                var elem = elementsArrayL[i]
                var distInView = elem.getBoundingClientRect().top - window.innerHeight + 20;
                if (distInView < 0) {
                    elem.classList.add("inView");
                } else {
                    elem.classList.remove("inView");
                }
            }
        }
        fadeInL();
    }


    if (document.querySelectorAll(".tile-r")) {
        let elementsArrayR = document.querySelectorAll(".tile-r");
        console.log(elementsArrayR);
        window.addEventListener('scroll', fadeInR);
        function fadeInR() {
            for (var i = 0; i < elementsArrayR.length; i++) {
                var elem = elementsArrayR[i]
                var distInView = elem.getBoundingClientRect().top - window.innerHeight + 20;
                if (distInView < 0) {
                    elem.classList.add("inView");
                } else {
                    elem.classList.remove("inView");
                }
            }
        }
        fadeInR();
    }

}

/* CARDS HOVER +++ */
function hoverFunction(clase) {
    let CardImg = document.querySelector(clase);
    CardImg.classList.add('card-img-hover')
    console.log('add ' + clase);
    /* $(clase).addClass('card-img-hover'); */
}
function leaveFunction(clase) {
    let CardImg = document.querySelector(clase);
    CardImg.classList.remove('card-img-hover')
    console.log('remove ' + clase);
    /* $(clase).removeClass('card-img-hover'); */
}
  /* /CARDS HOVER */