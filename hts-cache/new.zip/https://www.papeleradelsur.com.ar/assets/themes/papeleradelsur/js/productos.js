if (screen.width < 992) {
    let activeBTN = 0;
    function openSection(clase) {
        let btn = "on";
        if(activeBTN == 0){
            document.querySelector(clase).setAttribute("style", "top: 0");
            btn = "on";
        }
        if(activeBTN == 1){
            document.querySelector(clase).setAttribute("style", "");
            activeBTN--;
            btn = "off";
        }
        if(btn == "on"){
            activeBTN++;
        }    
    }
    let activeBTN2 = 0;
    function openSection2(clase) {
        let btn = "on";
        if(activeBTN2 == 0){
            document.querySelector(clase).setAttribute("style", "top: 0");
            btn = "on";
        }
        if(activeBTN2 == 1){
            document.querySelector(clase).setAttribute("style", "");
            activeBTN2--;
            btn = "off";
        }
        if(btn == "on"){
            activeBTN2++;
        }    
    }
    let activeBTN3 = 0;
    function openSection3(clase) {
        let btn = "on";
        if(activeBTN3 == 0){
            document.querySelector(clase).setAttribute("style", "top: 0");
            btn = "on";
        }
        if(activeBTN3 == 1){
            document.querySelector(clase).setAttribute("style", "");
            activeBTN3--;
            btn = "off";
        }
        if(btn == "on"){
            activeBTN3++;
        }    
    }
    let activeBTN4 = 0;
    function openSection4(clase) {
        let btn = "on";
        if(activeBTN4 == 0){
            document.querySelector(clase).setAttribute("style", "top: 0");
            btn = "on";
        }
        if(activeBTN4 == 1){
            document.querySelector(clase).setAttribute("style", "");
            activeBTN4--;
            btn = "off";
        }
        if(btn == "on"){
            activeBTN4++;
        }    
    }
}

// TABS CIRCULAR PORPUSE
const buttons = document.querySelectorAll('.btn-circle');
const tabInfo = document.querySelectorAll('.ciclo-info');

buttons.forEach((btn) => {
    btn.addEventListener('click', function(e) {
        buttons.forEach((btn) => {
        btn.classList.remove('selected');
      });
      e.currentTarget.classList.add('selected');
      tabInfo.forEach((info) => {
        info.classList.remove('show');
      });
      dataset = document.querySelector(e.currentTarget.dataset.content);
      if(dataset !== null){
        dataset.classList.add('show');
      }
      
    });
  });